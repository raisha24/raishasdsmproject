==============================================
About
==============================================

|product_name|
**************


Access the Slack Platform from your Python app. |product_name| lets you build on the Slack Web APIs pythonically.

|product_name| is proudly maintained with 💖 by the Slack Developer Tools team

- `License`_
- `Code of Conduct`_
- `Contributing`_
- `Contributor License Agreement`_

.. include:: metadata.rst