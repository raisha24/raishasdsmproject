.. Site settings
.. |product_name| replace:: Slack Developer Kit for Python
.. |email| replace:: opensource@slack.com
.. |repo_name| replace:: python-slackclient
.. |github_username| replace:: SlackAPI
.. |twitter_username| replace:: SlackAPI

.. _Bot Developer Hangout: https://dev4slack.slack.com/archives/sdk-python-slackclient
.. _Issue Tracker: http://github.com/SlackAPI/python-slackclient/issues
.. _pull request: http://github.com/SlackAPI/python-slackclient/pulls
.. _Python RTMBot: https://slackapi.github.io/python-rtmbot
.. _License: https://github.com/SlackAPI/python-slackclient/blob/master/LICENSE
.. _Code of Conduct: https://slackhq.github.io/code-of-conduct
.. _Contributing: https://github.com/slackapi/python-slackclient/blob/master/.github/contributing.md
.. _contributing guidelines: https://github.com/slackapi/python-slackclient/blob/master/.github/contributing.md
.. _Contributor License Agreement: https://docs.google.com/a/slack-corp.com/forms/d/e/1FAIpQLSfzjVoCM7ohBnjWf7eDYQxzti1EPpinsIJQA5RAUBwJKRUQHg/viewform
.. _Real Time Messaging (RTM) API: https://api.slack.com/rtm
.. _Web API: https://api.slack.com/web

