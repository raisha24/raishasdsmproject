from slackclient import SlackClient
token = “xoxb-453792396083-455441528115-rmzzaRaYx749XTpCw12QKe3a”
sc = SlackClient(token)
print sc.api_call(“api.test”)
print sc.api_call(“im.open”, user="UDB4DMDC0")